<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire d'ajout
    $nom = $_POST['nom'];
    $etat_sante = $_POST['etat_sante'];
    $taille = $_POST['taille'];
    $poids = $_POST['poids'];

    // Valide et échappe les données
    $nom = mysqli_real_escape_string($conn, $nom);
    $etat_sante = mysqli_real_escape_string($conn, $etat_sante);
    $taille = mysqli_real_escape_string($conn, $taille);
    $poids = mysqli_real_escape_string($conn, $poids);

    // Requête SQL pour ajouter le nouvel astronaute
    $sql = "INSERT INTO Astronauts (Nom, EtatSante, Taille, Poids) VALUES ('$nom', '$etat_sante', '$taille', '$poids')";

    if ($conn->query($sql) === TRUE) {
        echo "Astronaute ajouté avec succès.";
    } else {
        echo "Erreur lors de l'ajout de l'astronaute : " . $conn->error;
    }
}

// Affiche le formulaire pour ajouter un nouvel astronaute
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Astronaute</title>
</head>
<body>

<h2>Ajouter un Nouvel Astronaute</h2>

<form action="add_astronaut.php" method="post">
    <label for="nom">Nom de l'Astronaute:</label>
    <input type="text" id="nom" name="nom" required>
    <br>

    <label for="etat_sante">État de Santé:</label>
    <select id="etat_sante" name="etat_sante" required>
        <option value="Bon">Bon</option>
        <option value="Malade">Malade</option>
        <option value="Décédé">Décédé</option>
    </select>
    <br>

    <label for="taille">Taille:</label>
    <input type="text" id="taille" name="taille" required>
    <br>

    <label for="poids">Poids:</label>
    <input type="text" id="poids" name="poids" required>
    <br>

    <input type="submit" value="Ajouter Astronaute">
</form>

</body>
</html>
