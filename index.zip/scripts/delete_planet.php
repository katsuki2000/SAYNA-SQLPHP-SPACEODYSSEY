<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire de suppression
    $astronaut_id = $_POST['astronaut_id'];

    // Requête SQL pour supprimer l'astronaute
    $sql = "DELETE FROM Astronauts WHERE AstronauteID=$astronaut_id";

    if ($conn->query($sql) === TRUE) {
        echo "Astronaute supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression de l'astronaute : " . $conn->error;
    }
} else {
    // Affiche le formulaire de confirmation de suppression
    $astronaut_id = $_GET['id'];
    $result = $conn->query("SELECT * FROM Astronauts WHERE AstronauteID=$astronaut_id");
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer un Astronaute</title>
</head>
<body>

<h2>Confirmer la Suppression de l'Astronaute</h2>

<p>Êtes-vous sûr de vouloir supprimer l'astronaute "<?php echo $row['Nom']; ?>"?</p>

<form action="delete_astronaut.php" method="post">
    <input type="hidden" name="astronaut_id" value="<?php echo $row['AstronauteID']; ?>">
    <input type="submit" value="Confirmer la Suppression">
</form>

</body>
</html>
