<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifie si le formulaire est soumis
    $nom = $_POST['nom'];
    $circonference = $_POST['circonference'];
    $distance_terre = $_POST['distance_terre'];
    $documentation = $_POST['documentation'];

    // Valide et échappe les données (pour éviter les failles de sécurité)
    $nom = mysqli_real_escape_string($conn, $nom);
    $circonference = mysqli_real_escape_string($conn, $circonference);
    $distance_terre = mysqli_real_escape_string($conn, $distance_terre);
    $documentation = mysqli_real_escape_string($conn, $documentation);

    // Requête SQL pour ajouter la nouvelle planète
    $sql = "INSERT INTO Planets (Nom, Circonference, DistanceTerre, Documentation) VALUES ('$nom', '$circonference', '$distance_terre', '$documentation')";

    if ($conn->query($sql) === TRUE) {
        echo "Planète ajoutée avec succès.";
    } else {
        echo "Erreur lors de l'ajout de la planète : " . $conn->error;
    }
}

// Affiche le formulaire pour ajouter une nouvelle planète
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Planète</title>
</head>
<body>

<h2>Ajouter une Nouvelle Planète</h2>

<form action="add_planet.php" method="post">
    <label for="nom">Nom de la Planète:</label>
    <input type="text" id="nom" name="nom" required>
    <br>

    <label for="circonference">Circonférence:</label>
    <input type="text" id="circonference" name="circonference" required>
    <br>

    <label for="distance_terre">Distance à la Terre:</label>
    <input type="text" id="distance_terre" name="distance_terre" required>
    <br>

    <label for="documentation">Documentation:</label>
    <textarea id="documentation" name="documentation" required></textarea>
    <br>

    <input type="submit" value="Ajouter Planète">
</form>

</body>
</html>
