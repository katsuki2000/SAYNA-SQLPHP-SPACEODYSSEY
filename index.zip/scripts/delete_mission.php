<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire de suppression
    $mission_id = $_POST['mission_id'];

    // Requête SQL pour supprimer la mission
    $sql = "DELETE FROM Missions WHERE MissionID=$mission_id";

    if ($conn->query($sql) === TRUE) {
        // Supprime les associations d'astronautes
        $conn->query("DELETE FROM AstronautsMissions WHERE MissionID=$mission_id");

        echo "Mission supprimée avec succès.";
    } else {
        echo "Erreur lors de la suppression de la mission :
" . $conn->error;
    }
} else {
    // Affiche le formulaire de confirmation de suppression
    $mission_id = $_GET['id'];
    $result_mission = $conn->query("SELECT * FROM Missions WHERE MissionID=$mission_id");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supprimer une Mission</title>
</head>
<body>

<h2>Confirmer la Suppression de la Mission</h2>

<p>Êtes-vous sûr de vouloir supprimer la mission "<?php echo $row_mission['NomMission']; ?>"?</p>

<form action="delete_mission.php" method="post">
    <input type="hidden" name="mission_id" value="<?php echo $row_mission['MissionID']; ?>">
    <input type="submit" value="Confirmer la Suppression">
</form>

</body>
</html>
