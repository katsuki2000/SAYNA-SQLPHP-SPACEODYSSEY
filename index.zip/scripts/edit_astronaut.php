<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire de modification
    $astronaut_id = $_POST['astronaut_id'];
    $nom = $_POST['nom'];
    $etat_sante = $_POST['etat_sante'];
    $taille = $_POST['taille'];
    $poids = $_POST['poids'];

    // Valide et échappe les données
    $nom = mysqli_real_escape_string($conn, $nom);
    $etat_sante = mysqli_real_escape_string($conn, $etat_sante);
    $taille = mysqli_real_escape_string($conn, $taille);
    $poids = mysqli_real_escape_string($conn, $poids);

    // Requête SQL pour mettre à jour l'astronaute
    $sql = "UPDATE Astronauts SET Nom='$nom', EtatSante='$etat_sante', Taille='$taille', Poids='$poids' WHERE AstronauteID=$astronaut_id";

    if ($conn->query($sql) === TRUE) {
        echo "Astronaute mis à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour de l'astronaute : " . $conn->error;
    }
} else {
    // Affiche le formulaire de modification
    $astronaut_id = $_GET['id'];
    $result = $conn->query("SELECT * FROM Astronauts WHERE AstronauteID=$astronaut_id");
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Astronaute</title>
</head>
<body>

<h2>Modifier un Astronaute</h2>

<form action="edit_astronaut.php" method="post">
    <input type="hidden" name="astronaut_id" value="<?php echo $row['AstronauteID']; ?>">

    <label for="nom">Nom de l'Astronaute:</label>
    <input type="text" id="nom" name="nom" value="<?php echo $row['Nom']; ?>" required>
    <br>

    <label for="etat_sante">État de Santé:</label>
    <select id="etat_sante" name="etat_sante" required>
        <option value="Bon" <?php if ($row['EtatSante'] === 'Bon') echo 'selected'; ?>>Bon</option>
        <option value="Malade" <?php if ($row['EtatSante'] === 'Malade') echo 'selected'; ?>>Malade</option>
        <option value="Décédé" <?php if ($row['EtatSante'] === 'Décédé') echo 'selected'; ?>>Décédé</option>
    </select>
    <br>

    <label for="taille">Taille:</label>
    <input type="text" id="taille" name="taille" value="<?php echo $row['Taille']; ?>" required>
    <br>

    <label for="poids">Poids:</label>
    <input type="text" id="poids" name="poids" value="<?php echo $row['Poids']; ?>" required>
    <br>

    <input type="submit" value="Modifier Astronaute">
</form>

</body>
</html>
