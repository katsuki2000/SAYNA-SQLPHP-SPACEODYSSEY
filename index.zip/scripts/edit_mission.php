<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire de modification
    $mission_id = $_POST['mission_id'];
    $nom_mission = $_POST['nom_mission'];
    $vaisseau_id = $_POST['vaisseau_id'];
    $astronautes = $_POST['astronautes'];
    $planete_id = $_POST['planete_id'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];
    $status = $_POST['status'];

    // Valide et échappe les données
    $nom_mission = mysqli_real_escape_string($conn, $nom_mission);
    $vaisseau_id = mysqli_real_escape_string($conn, $vaisseau_id);
    $planete_id = mysqli_real_escape_string($conn, $planete_id);
    $date_debut = mysqli_real_escape_string($conn, $date_debut);
    $date_fin = mysqli_real_escape_string($conn, $date_fin);
    $status = mysqli_real_escape_string($conn, $status);

    // Requête SQL pour mettre à jour la mission
    $sql = "UPDATE Missions SET NomMission='$nom_mission', VaisseauID='$vaisseau_id', PlaneteID='$planete_id', DateDebut='$date_debut', DateFin='$date_fin', Status='$status' WHERE MissionID=$mission_id";

    if ($conn->query($sql) === TRUE) {
        // Supprime les anciennes associations d'astronautes
        $conn->query("DELETE FROM AstronautsMissions WHERE MissionID=$mission_id");

        // Associe les astronautes à la mission
        foreach ($astronautes as $astronaute_id) {
            $sql_astronaute = "INSERT INTO AstronautsMissions (AstronauteID, MissionID) VALUES ('$astronaute_id', '$mission_id')";
            $conn->query($sql_astronaute);
        }

        echo "Mission mise à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour de la mission : " . $conn->error;
    }
} else {
    // Affiche le formulaire de modification
    $mission_id = $_GET['id'];
    $result_mission = $conn->query("SELECT * FROM Missions WHERE MissionID=$mission_id");
    $result_vaisseaux = $conn->query("SELECT * FROM Vaisseaux");
    $result_planetes = $conn->query("SELECT * FROM Planets");
    $result_astronautes = $conn->query("SELECT * FROM Astronauts");
    $result_astronautes_assigned = $conn->query("SELECT AstronauteID FROM AstronautsMissions WHERE MissionID=$mission_id");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Mission</title>
</head>
<body>

<h2>Modifier une Mission</h2>

<form action="edit_mission.php" method="post">
    <input type="hidden" name="mission_id" value="<?php echo $mission_id; ?>">

    <label for="nom_mission">Nom de la Mission:</label>
    <input type="text" id="nom_mission" name="nom_mission" value="<?php echo $row_mission['NomMission']; ?>" required>
    <br>

    <label for="vaisseau_id">Vaisseau:</label>
    <select id="vaisseau_id" name="vaisseau_id" required>
        <?php while ($row_vaisseau = $result_vaisseaux->fetch_assoc()) : ?>
            <option value="<?php echo $row_vaisseau['VaisseauID']; ?>" <?php if ($row_mission['VaisseauID'] == $row_vaisseau['VaisseauID']) echo 'selected'; ?>>
                <?php echo $row_vaisseau['NomVaisseau']; ?>
            </option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="astronautes[]">Astronautes:</label>
    <select id="astronautes" name="astronautes[]" multiple required>
        <?php while ($row_astronaute = $result_astronautes->fetch_assoc()) : ?>
            <option value="<?php echo $row_astronaute['AstronauteID']; ?>" <?php if (in_array($row_astronaute['AstronauteID'], $assigned_astronauts)) echo 'selected'; ?>>
                <?php echo $row_astronaute['Nom']; ?>
            </option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="planete_id">Planète:</label>
    <select id="planete_id" name="planete_id" required>
        <?php while ($row_planete = $result_planetes->fetch_assoc()) : ?>
            <option value="<?php echo $row_planete['PlaneteID']; ?>" <?php if ($row_mission['PlaneteID'] == $row_planete['PlaneteID']) echo 'selected'; ?>>
                <?php echo $row_planete['Nom']; ?>
            </option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="date_debut">Date de Début:</label>
    <input type="date" id="date_debut" name="date_debut" value="<?php echo $row_mission['DateDebut']; ?>" required>
    <br>

    <label for="date_fin">Date de Fin:</label>
    <input type="date" id="date_fin" name="date_fin" value="<?php echo $row_mission['DateFin']; ?>" required>
    <br>

    <label for="status">Status:</label>
    <select id="status" name="status" required>
        <option value="En préparation" <?php if ($row_mission['Status'] == 'En préparation') echo 'selected'; ?>>En préparation</option>
        <option value="En cours" <?php if ($row_mission['Status'] == 'En cours') echo 'selected'; ?>>En cours</option>
        <option value="Terminée" <?php if ($row_mission['Status'] == 'Terminée') echo 'selected'; ?>>Terminée</option>
        <option value="Abandonnée" <?php if ($row_mission['Status'] == 'Abandonnée') echo 'selected'; ?>>Abandonnée</option>
    </select>
    <br>

    <input type="submit" value="Modifier Mission">
</form>

</body>
</html>
