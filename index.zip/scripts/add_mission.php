<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire d'ajout de mission
    $nom_mission = $_POST['nom_mission'];
    $vaisseau_id = $_POST['vaisseau_id'];
    $astronautes = $_POST['astronautes'];
    $planete_id = $_POST['planete_id'];
    $date_debut = $_POST['date_debut'];
    $date_fin = $_POST['date_fin'];
    $status = $_POST['status'];

    // Valide et échappe les données
    $nom_mission = mysqli_real_escape_string($conn, $nom_mission);
    $vaisseau_id = mysqli_real_escape_string($conn, $vaisseau_id);
    $planete_id = mysqli_real_escape_string($conn, $planete_id);
    $date_debut = mysqli_real_escape_string($conn, $date_debut);
    $date_fin = mysqli_real_escape_string($conn, $date_fin);
    $status = mysqli_real_escape_string($conn, $status);

    // Requête SQL pour ajouter la nouvelle mission
    $sql = "INSERT INTO Missions (NomMission, VaisseauID, PlaneteID, DateDebut, DateFin, Status) VALUES ('$nom_mission', '$vaisseau_id', '$planete_id', '$date_debut', '$date_fin', '$status')";

    if ($conn->query($sql) === TRUE) {
        // Associe les astronautes à la mission
        $mission_id = $conn->insert_id;
        foreach ($astronautes as $astronaute_id) {
            $sql_astronaute = "INSERT INTO AstronautsMissions (AstronauteID, MissionID) VALUES ('$astronaute_id', '$mission_id')";
            $conn->query($sql_astronaute);
        }

        echo "Mission ajoutée avec succès.";
    } else {
        echo "Erreur lors de l'ajout de la mission : " . $conn->error;
    }
}

// Récupère la liste des vaisseaux et des planètes pour les options du formulaire
$result_vaisseaux = $conn->query("SELECT * FROM Vaisseaux");
$result_planetes = $conn->query("SELECT * FROM Planets");
$result_astronautes = $conn->query("SELECT * FROM Astronauts");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Mission</title>
</head>
<body>

<h2>Ajouter une Nouvelle Mission</h2>

<form action="add_mission.php" method="post">
    <label for="nom_mission">Nom de la Mission:</label>
    <input type="text" id="nom_mission" name="nom_mission" required>
    <br>

    <label for="vaisseau_id">Vaisseau:</label>
    <select id="vaisseau_id" name="vaisseau_id" required>
        <?php while ($row = $result_vaisseaux->fetch_assoc()) : ?>
            <option value="<?php echo $row['VaisseauID']; ?>"><?php echo $row['NomVaisseau']; ?></option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="astronautes[]">Astronautes:</label>
    <select id="astronautes" name="astronautes[]" multiple required>
        <?php while ($row = $result_astronautes->fetch_assoc()) : ?>
            <option value="<?php echo $row['AstronauteID']; ?>"><?php echo $row['Nom']; ?></option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="planete_id">Planète:</label>
    <select id="planete_id" name="planete_id" required>
        <?php while ($row = $result_planetes->fetch_assoc()) : ?>
            <option value="<?php echo $row['PlaneteID']; ?>"><?php echo $row['Nom']; ?></option>
        <?php endwhile; ?>
    </select>
    <br>

    <label for="date_debut">Date de Début:</label>
    <input type="date" id="date_debut" name="date_debut" required>
    <br>

    <label for="date_fin">Date de Fin:</label>
    <input type="date" id="date_fin" name="date_fin" required>
    <br>

    <label for="status">Status:</label>
    <select id="status" name="status" required>
        <option value="En préparation">En préparation</option>
        <option value="En cours">En cours</option>
        <option value="Terminée">Terminée</option>
        <option value="Abandonnée">Abandonnée</option>
    </select>
    <br>

    <input type="submit" value="Ajouter Mission">
</form>

</body>
</html>
