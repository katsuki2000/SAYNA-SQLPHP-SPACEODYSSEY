<?php
include'../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Traitement du formulaire de modification
    $planet_id = $_POST['planet_id'];
    $nom = $_POST['nom'];
    $circonference = $_POST['circonference'];
    $distance_terre = $_POST['distance_terre'];
    $documentation = $_POST['documentation'];

    // Valide et échappe les données
    $nom = mysqli_real_escape_string($conn, $nom);
    $circonference = mysqli_real_escape_string($conn, $circonference);
    $distance_terre = mysqli_real_escape_string($conn, $distance_terre);
    $documentation = mysqli_real_escape_string($conn, $documentation);

    // Requête SQL pour mettre à jour la planète
    $sql = "UPDATE Planets SET Nom='$nom', Circonference='$circonference', DistanceTerre='$distance_terre', Documentation='$documentation' WHERE PlaneteID=$planet_id";

    if ($conn->query($sql) === TRUE) {
        echo "Planète mise à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour de la planète : " . $conn->error;
    }
} else {
    // Affiche le formulaire de modification
    $planet_id = $_GET['id'];
    $result = $conn->query("SELECT * FROM Planets WHERE PlaneteID=$planet_id");
    $row = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Planète</title>
</head>
<body>

<h2>Modifier une Planète</h2>

<form action="edit_planet.php" method="post">
    <input type="hidden" name="planet_id" value="<?php echo $row['PlaneteID']; ?>">

    <label for="nom">Nom de la Planète:</label>
    <input type="text" id="nom" name="nom" value="<?php echo $row['Nom']; ?>" required>
    <br>

    <label for="circonference">Circonférence:</label>
    <input type="text" id="circonference" name="circonference" value="<?php echo $row['Circonference']; ?>" required>
    <br>

    <label for="distance_terre">Distance à la Terre:</label>
    <input type="text" id="distance_terre" name="distance_terre" value="<?php echo $row['DistanceTerre']; ?>" required>
    <br>

    <label for="documentation">Documentation:</label>
    <textarea id="documentation" name="documentation" required><?php echo $row['Documentation']; ?></textarea>
    <br>

    <input type="submit" value="Modifier Planète">
</form>

</body>
</html>
