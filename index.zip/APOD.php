<?php
// Emplacement du fichier cache
$cache_file = 'apod_cache.json';

// Vérifie si le fichier cache existe et s'il a été modifié aujourd'hui
if (file_exists($cache_file) && filemtime($cache_file) > strtotime('today')) {
    // Utilise les données du cache
    $apod_data = json_decode(file_get_contents($cache_file));
} else {
    // Appel à l'API de la NASA pour l'APOD
    $apod_url = "https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY";
    $apod_data = json_decode(file_get_contents($apod_url));

    // Sauvegarde les données dans le cache
    file_put_contents($cache_file, json_encode($apod_data));
}

// Affiche l'APOD
if ($apod_data && isset($apod_data->url)) {
    echo "<img src='{$apod_data->url}' class='img-fluid' alt='Astronomy Picture of the Day'>";
    echo "<p>{$apod_data->title}</p>";
    echo "<p>{$apod_data->explanation}</p>";
} else {
    echo "Impossible de récupérer l'APOD pour le moment.";
}
?>
