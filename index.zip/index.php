<?php
include('config.php');
include('pages/header.php');
include('pages/menuGauche.php');
?>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- ... (Le reste du code reste inchangé) ... -->
</aside>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Stellar Tech</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Missions Intergalactiques</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <!-- Ajout du paragraphe d'introduction -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Bienvenue sur l'application de gestion intergalactique de Stellar Tech!</h4>
                            <p class="card-text">
                                Explorez de nouveaux mondes, suivez les missions spatiales, et découvrez chaque jour l'image astronomique du jour avec notre application avancée.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Fin ajout du paragraphe d'introduction -->

    <!-- Ajout du Dashboard -->
    <?php include "pages/dashboard.php"; ?>
    <!-- Fin ajout du Dashboard -->

    <!-- Affichage de l'APOD -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Astronomy Picture of the Day</h3>
                </div>
                <div class="card-body">
                    <?php include "apod.php"; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Fin affichage de l'APOD -->

    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include "pages/footer.php"; ?>
