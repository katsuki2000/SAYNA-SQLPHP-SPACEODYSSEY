<?php
include('../config.php');
include('header.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h2>Liste des Vaisseaux</h2>

            <?php
            $result = $conn->query("SELECT * FROM vaisseaux");
            if ($result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>{$row['nom']} - Capacité : {$row['capacite']}</li>";
                    // Affiche d'autres informations si nécessaire
                }
                echo "</ul>";
            } else {
                echo "Aucun vaisseau n'a été trouvé.";
            }
            ?>
        </div>
        <div class="col-md-6">
            <h2>Ajouter un Vaisseau</h2>

            <?php include('../scripts/add_vaisseau_form.php'); ?>
        </div>
    </div>
</div>

<?php
include('footer.php');
?>
