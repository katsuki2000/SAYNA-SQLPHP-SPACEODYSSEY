<?php
include('../config.php');
include('header.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <h2>Astronomy Picture of the Day</h2>

            <?php
            $apod_cache_file = 'apod_cache.txt';
            $apod_api_url = 'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY';

            // Vérifie si le cache existe et s'il est à jour
            if (file_exists($apod_cache_file) && time() - filemtime($apod_cache_file) < 86400) {
                // Utilise le cache
                $apod_data = file_get_contents($apod_cache_file);
            } else {
                // Appelle l'API de la NASA et met à jour le cache
                $apod_data = file_get_contents($apod_api_url);
                file_put_contents($apod_cache_file, $apod_data);
            }

            $apod_data = json_decode($apod_data, true);

            if ($apod_data && isset($apod_data['url'])) {
                echo "<img src='{$apod_data['url']}' alt='Astronomy Picture of the Day' class='img-fluid'>";
            } else {
                echo "Impossible de récupérer l'Astronomy Picture of the Day.";
            }
            ?>
        </div>
    </div>
</div>

<?php
include('footer.php');
?>
