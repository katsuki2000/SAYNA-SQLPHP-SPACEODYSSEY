<!-- Sidebar Menu -->
<nav class="mt-2">
    <ul class="nav nav-treeview">
        <li class="nav-item">
            <a href="./pages/planetes.php" class="nav-link">
                <p>Planètes</p>
            </a>
        </li>
        <li class="nav-item">
            <a href="./pages/astronautes.php" class="nav-link">
                <p>Astronautes </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="./pages/missions.php" class="nav-link">
                <p>Missions </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="./pages/vaisseaux.php" class="nav-link">
                <p>Vaisseaux </p>
            </a>
        </li>
    </ul>
</nav>
<!-- /.sidebar-menu -->