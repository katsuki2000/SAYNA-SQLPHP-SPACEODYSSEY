<?php
include('../config.php');
include('header.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h2>Liste des Planètes</h2>

            <?php
            $result = $conn->query("SELECT * FROM planetes");
            if ($result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>{$row['nom']} - Distance à la Terre : {$row['distance_terre']} km</li>";
                    // Affiche d'autres informations si nécessaire
                }
                echo "</ul>";
            } else {
                echo "Aucune planète n'a été trouvée.";
            }
            ?>
        </div>
        <div class="col-md-6">
            <h2>Ajouter une Planète</h2>

            <?php include('../scripts/add_planet_form.php'); ?>
        </div>
    </div>
</div>

<?php
include('footer.php');
?>
