<?php
include('../config.php');
include('header.php');
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h2>Liste des Astronautes</h2>

            <?php
            $result = $conn->query("SELECT * FROM astronautes");
            if ($result->num_rows > 0) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>{$row['nom']} - État de santé : {$row['etat_sante']}</li>";
                    // Affiche d'autres informations si nécessaire
                }
                echo "</ul>";
            } else {
                echo "Aucun astronaute n'a été trouvé.";
            }
            ?>
        </div>
        <div class="col-md-6">
            <h2>Ajouter un Astronaute</h2>

            <?php include('../scripts/add_astronaute_form.php'); ?>
        </div>
    </div>
</div>

<?php
include('footer.php');
?>
